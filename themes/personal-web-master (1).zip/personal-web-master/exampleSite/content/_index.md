---
title: HOME
description: Welcome to this sample project
images: ["/images/sample.jpg"]
---

Hey,

I'm Edna West, a Web Developer and Entrepreneur.

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus error cumque quisquam necessitatibus libero dolore porro, quo at molestiae modi voluptatibus iusto alias corporis. Accusamus, debitis, atque. Maiores, distinctio, neque.

[Get to know me better](/about "Get to know me better")