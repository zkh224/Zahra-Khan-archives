---
title: ABOUT
description: Hey, I'm Edna West
images: ["/images/sample.jpg"]
---


This is my about page. :wave:

Lorem ipsum dolor sit amet, :smile: consectetur adipisicing elit. Voluptates aut, tenetur distinctio voluptatibus ab. Nihil id dignissimos unde, tenetur iusto facilis suscipit corporis, ipsam necessitatibus, eaque iste deleniti consequuntur reprehenderit? :earth_africa: